This is a Flutter based Notes App, which is protected by FaceID, TouchID or any other safety authentications in your local machine.

This project uses flutter plugins like localauth, sqflite and other to import various functionalities.

Latest Android Version(12) is required for FACEID to be working properly.(Does not support UIs like MIUI or VIVOui for FACEID)

To avail the features of FACEID one should have it already setup in his/her device.

If FACEID is not available then FINGERPRINT would be the way to authenticate, if neither works on your device then you can authenticate with your PIN/PATTERN.
